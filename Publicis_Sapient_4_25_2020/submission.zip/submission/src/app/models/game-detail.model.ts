export interface GameDetail {
    title: string;
    url: string;
    platform: string;
    score: string;
    genre: string;
    editorsChoice: string;
    releaseYear: string;
}